package com.example.task_02.smart

import android.util.Log
import android.view.LayoutInflater
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.task_02.Data.SmartPhone
import com.example.task_02.MainActivity
import com.example.task_02.OnItemClickListener
import com.example.task_02.databinding.Item3Binding
import com.example.task_02.databinding.StockbuyBinding
import kotlin.coroutines.coroutineContext

class PriceAdapter (listPrc: ArrayList<String>,onClickListener:OnClickListener) : RecyclerView.Adapter<PriceAdapter.MyViewHolder>() {

    private var priceList = listPrc
    private var onClickListener:OnClickListener? = null

    class MyViewHolder(var binding: Item3Binding): RecyclerView.ViewHolder(binding.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PriceAdapter.MyViewHolder {
        val itemView = Item3Binding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PriceAdapter.MyViewHolder, position: Int) {
        val currentItem =priceList[position]

        holder.binding.apply {
//            pName.text = currentItem.price.toString()
//            pCode.text = currentItem.productCode.toString()
                button3.text = currentItem.toString()
        }

        holder.binding.button3.setOnClickListener {
            onClickListener?.onClick(position,currentItem)
        }

    }

    override fun getItemCount(): Int {
        return priceList.size
    }

    // A function to bind the onclickListener.
    fun setOnClickListener(onClickListener: OnClickListener) {
        this.onClickListener = onClickListener
    }

    // onClickListener Interface
    interface OnClickListener {
        fun onClick(position: Int, model: String)
    }


}