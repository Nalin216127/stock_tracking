package com.example.task_02.smart

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.task_02.Data.SmartPhone
import com.example.task_02.R
import com.example.task_02.databinding.Item1Binding
import org.json.JSONArray
import org.json.JSONException
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader

class SmartFragment:Fragment() {
    private val binding by lazy { Item1Binding.inflate(layoutInflater) }
    private lateinit var listIm:ArrayList<SmartPhone>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addItemsFromJSON()
        Log.d("list",listIm.size.toString())
        val imitemAdapter=SmartAdapter(listIm)
        binding.phoneRv.layoutManager= LinearLayoutManager(context)

        binding.phoneRv.adapter = imitemAdapter


    }

    private fun addItemsFromJSON() {
        try {
            val jsonDataString = readJSONDataFromFile("smartphone.json")
            val jsonArray = JSONArray(jsonDataString)
            for (i in 0 until jsonArray.length()) {
                val itemObj = jsonArray.getJSONObject(i)


                val productName=itemObj.getString("productName")
                val productCode=itemObj.getString("productCode")
                val im=SmartPhone(productName,productCode,1)

                listIm.add(im)
            }
        } catch (e: JSONException) {
            Log.d("Taf", "addItemsFromJSON: ", e)
        } catch (e: IOException) {
            Log.d("taf", "addItemsFromJSON: ", e)
        }
    }

    @Throws(IOException::class)
    private fun readJSONDataFromFile(fileName:String): String {
        var inputStream: InputStream? = null
        val builder = StringBuilder()
        try {
            var jsonString: String? = null

            inputStream = resources.openRawResource(R.raw.smartphone)

            val bufferedReader = BufferedReader(
                InputStreamReader(inputStream, "UTF-8")
            )
            while (bufferedReader.readLine().also { jsonString = it } != null) {
                builder.append(jsonString)
            }
        } finally {
            inputStream?.close()
        }
        return String(builder)
    }






}