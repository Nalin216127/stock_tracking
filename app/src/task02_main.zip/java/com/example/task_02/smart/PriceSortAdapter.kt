//package com.example.task_02.smart
//
//import android.view.ViewGroup
//import androidx.recyclerview.widget.RecyclerView
//import com.example.task_02.databinding.Item2Binding
//
//class PriceSortAdapter(): RecyclerView.Adapter<PriceSortAdapter.MyViewHolder>() {
//    override fun onCreateViewHolder(
//        parent: ViewGroup,
//        viewType: Int
//    ): PriceSortAdapter.MyViewHolder {
//        TODO("Not yet implemented")
//    }
//
//    class MyViewHolder(var binding:Item2Binding):RecyclerView.ViewHolder() {
//    }
//
//    override fun onBindViewHolder(holder: PriceSortAdapter.MyViewHolder, position: Int) {
//        TODO("Not yet implemented")
//    }
//
//    override fun getItemCount(): Int {
//        TODO("Not yet implemented")
//    }
//
//}