package com.example.task_02.smart

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.task_02.Data.SmartPhone
import com.example.task_02.databinding.Item2Binding

class SmartAdapter(listIm: ArrayList<SmartPhone>) :RecyclerView.Adapter<SmartAdapter.MyViewHolder>() {

    private var phoneList = listIm


    class MyViewHolder(var binding:Item2Binding):RecyclerView.ViewHolder(binding.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SmartAdapter.MyViewHolder {
        val itemView = Item2Binding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyViewHolder(itemView)
    }

    fun filterList(filterlist: ArrayList<SmartPhone>) {
        // below line is to add our filtered
        // list in our course array list.
        phoneList = filterlist
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: SmartAdapter.MyViewHolder, position: Int) {
        val currentItem =phoneList[position]

        holder.binding.apply {
            pName.text = currentItem.productName.toString()
            pCode.text = currentItem.productCode.toString()
        }


        holder.binding.plus.setOnClickListener {
            var number = Integer.parseInt(holder.binding.itemCount.getText().toString())
            number++

            holder.binding.itemCount.setText(number.toString())
        }


        holder.binding.minus.setOnClickListener {
            var number = Integer.parseInt(holder.binding.itemCount.getText().toString())
            if (number<=0){
                number = 0
            }
            else{
                number--
            }
            holder.binding.itemCount.setText(number.toString())
        }
    }

    override fun getItemCount(): Int {
        return phoneList.size
    }

    fun setData(){

    }

}