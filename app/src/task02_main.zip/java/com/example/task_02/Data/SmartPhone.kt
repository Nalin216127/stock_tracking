package com.example.task_02.Data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName


@Entity(tableName = "smart_phone")
data class SmartPhone(
    @SerializedName("productName")
    val productName:String,
    @PrimaryKey
    @SerializedName("productCode")
    val productCode:String,
    @SerializedName("price")
    val price:Int
)