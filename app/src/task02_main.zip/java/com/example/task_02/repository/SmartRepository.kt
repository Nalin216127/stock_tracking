package com.example.task_02.repository

import androidx.lifecycle.LiveData
import com.example.task_02.Dao.SmartphoneDao
import com.example.task_02.Data.SmartPhone
import javax.inject.Inject

class SmartRepository @Inject constructor(private val smartphoneDao: SmartphoneDao) {
        fun getAllData(): List<SmartPhone> =smartphoneDao.getPhones()
}