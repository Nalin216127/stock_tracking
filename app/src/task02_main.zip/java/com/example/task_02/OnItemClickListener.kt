package com.example.task_02

import android.view.View
import java.text.FieldPosition

interface OnItemClickListener {
    fun onItemClick(position: Int,model: Smartphone)
}