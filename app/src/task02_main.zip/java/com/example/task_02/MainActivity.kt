package com.example.task_02

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.SearchView
import android.widget.SearchView.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.task_02.Data.SmartPhone
import com.example.task_02.databinding.StockbuyBinding
import com.example.task_02.smart.PriceAdapter
import com.example.task_02.smart.SmartAdapter
import com.example.task_02.smart.SmartFragment
import org.json.JSONArray
import org.json.JSONException
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader


class MainActivity : AppCompatActivity(), PriceAdapter.OnClickListener {

    private val binding: StockbuyBinding by lazy { StockbuyBinding.inflate(layoutInflater) }
    private var listIm=ArrayList<SmartPhone>()
    private var listPrice=ArrayList<String>()
    private lateinit var imitemAdapter:SmartAdapter
    lateinit var searchView: SearchView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        addItemsFromJSON(com.example.task_02.R.raw.smartphones)

        addPriceItemsFromJSON()
        Log.d("list",listPrice.size.toString())
        imitemAdapter= SmartAdapter(listIm)
        binding.phoneRv.layoutManager= LinearLayoutManager(applicationContext)

        binding.phoneRv.adapter = imitemAdapter


        val priceItemAdapter= PriceAdapter(listPrice, this)
        binding.priceRv.layoutManager= LinearLayoutManager(applicationContext,LinearLayoutManager.HORIZONTAL,false)


        binding.priceRv.adapter = priceItemAdapter

        binding.submitButton.setOnClickListener{
//            listIm.clear()
            Toast.makeText(this, "Clicked", Toast.LENGTH_SHORT).show()
//            addItemsFromJSON(com.example.task_02.R.raw.price1)
//            imitemAdapter.notifyDataSetChanged()
        }

        searchView = findViewById(R.id.search)


        searchView.setOnQueryTextListener(object : OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(msg: String): Boolean {
                filter(msg)
                imitemAdapter.notifyDataSetChanged()
                return false
            }
        })

//        binding.priceRv.setOnClickListener {
//            listIm.clear()
//            addItemsFromJSON(com.example.task_02.R.raw.price1)
//            imitemAdapter.notifyDataSetChanged()
//        }


        binding.btnDown.setOnClickListener {
            binding.priceRv.visibility = VISIBLE
            binding.phoneRv.visibility = VISIBLE
            binding.btnUp.visibility  = VISIBLE
            binding.btnDown.visibility = GONE
        }


        binding.btnUp.setOnClickListener {
            binding.priceRv.visibility = GONE
            binding.phoneRv.visibility = GONE
            binding.btnDown.visibility = VISIBLE
            binding.btnUp.visibility  = GONE
        }

    }


    private fun filter(text: String) {
        // creating a new array list to filter our data.
        val filteredlist: ArrayList<SmartPhone> = ArrayList()

        // running a for loop to compare elements.
        for (item in listIm) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.productName.toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item)
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show()
        } else {
            imitemAdapter.filterList(filteredlist)
        }
    }





//    fun pricecat(p:Int){
//        if(p=p1){
//            listIm.clear()
//            Toast.makeText(this, "Clicked", Toast.LENGTH_SHORT).show()
//            addItemsFromJSON(com.example.task_02.R.raw.price1)
//            imitemAdapter.notifyDataSetChanged()
//        }
//        else if(p=p2){
//            listIm.clear()
//            Toast.makeText(this, "Clicked", Toast.LENGTH_SHORT).show()
//            addItemsFromJSON(com.example.task_02.R.raw.price2)
//            imitemAdapter.notifyDataSetChanged()
//        }
//    }

    private fun addItemsFromJSON(ids:Int) {
        try {
            val jsonDataString = readJSONDataFromFile(ids)
            val jsonArray = JSONArray(jsonDataString)
            for (i in 0 until jsonArray.length()) {
                val itemObj = jsonArray.getJSONObject(i)


                val productName=itemObj.getString("productName")
                val productCode=itemObj.getString("productCode")
                val price=itemObj.getInt("price")

                val im=SmartPhone(productName,productCode,price)

                listIm.add(im)
            }
        } catch (e: JSONException) {
            Log.d("Taf", "addItemsFromJSON: ", e)
        } catch (e: IOException) {
            Log.d("taf", "addItemsFromJSON: ", e)
        }
    }



    private fun addPriceItemsFromJSON() {
        try {
            val jsonDataString = readJSONDataFromFile(com.example.task_02.R.raw.price)
            val jsonArray = JSONArray(jsonDataString)
            for (i in 0 until jsonArray.length()) {
                val itemObj = jsonArray.getJSONObject(i)


                val price=itemObj.getString("price")


                listPrice.add(price)
            }
        } catch (e: JSONException) {
            Log.d("Taf", "addItemsFromJSON: ", e)
        } catch (e: IOException) {
            Log.d("taf", "addItemsFromJSON: ", e)
        }
    }


    @Throws(IOException::class)
    private fun readJSONDataFromFile(id:Int): String {
        var inputStream: InputStream? = null
        val builder = StringBuilder()
        try {
            var jsonString: String? = null

            inputStream = resources.openRawResource(id)

            val bufferedReader = BufferedReader(
                InputStreamReader(inputStream, "UTF-8")
            )
            while (bufferedReader.readLine().also { jsonString = it } != null) {
                builder.append(jsonString)
            }
        } finally {
            inputStream?.close()
        }
        return String(builder)
    }

    override fun onClick(position: Int, model: String) {
        Toast.makeText(this,"position",Toast.LENGTH_SHORT).show()
        Log.d("position","pos")
    }

//
//    @Throws(IOException::class)
//    private fun readpriceJSONDataFromFile(): String {
//        var inputStream: InputStream? = null
//        val builder = StringBuilder()
//        try {
//            var jsonString: String? = null
//
//            inputStream = resources.openRawResource(com.example.task_02.R.raw.price)
//
//            val bufferedReader = BufferedReader(
//                InputStreamReader(inputStream, "UTF-8")
//            )
//            while (bufferedReader.readLine().also { jsonString = it } != null) {
//                builder.append(jsonString)
//            }
//        } finally {
//            inputStream?.close()
//        }
//        return String(builder)
//    }


}


