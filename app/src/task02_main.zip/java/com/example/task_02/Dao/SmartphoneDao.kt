package com.example.task_02.Dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.task_02.Data.SmartPhone
import java.util.concurrent.Flow

@Dao
interface SmartphoneDao {

    @Query("SELECT * FROM smart_phone")
    fun getPhones(): List<SmartPhone>

    @Insert
    suspend fun insertSmartPhone(smartphone:SmartPhone)


}