package com.example.task_02.Dao

import android.content.Context
import android.util.Log
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.task_02.Data.SmartPhone
import com.example.task_02.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray

class PrepopulateRoomCallBack(private val context: Context):RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)

        CoroutineScope(Dispatchers.IO).launch {
            prePopulatePhones(context)
        }
    }

    private suspend fun prePopulatePhones(context: Context) {
        try {
            val smartphoneDao = SmartDatabase.getDatabase(context).smartphoneDao()

            val phoneList: JSONArray =
                context.resources.openRawResource(R.raw.smartphone).bufferedReader().use {
                    JSONArray(it.readText())
                }

            phoneList.takeIf { it.length() > 0 }?.let { list ->
                for (index in 0 until list.length()) {
                    val phoneObj = list.getJSONObject(index)
                    smartphoneDao.insertSmartPhone(
                        SmartPhone(
                            phoneObj.getString("productName"),
                            phoneObj.getString("productCode"),
                            phoneObj.getInt("price")

                        )
                    )
                }
                Log.e("Smart App","successfully pre-populated users into database")
            }
        } catch (exception:Exception){
            Log.e(
                "smartApp",
                exception.localizedMessage ?: "failed to pre-populate users into database"
            )
        }
    }

}