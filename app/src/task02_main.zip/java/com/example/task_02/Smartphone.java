package com.example.task_02;

public class Smartphone {
    private String productName;
    private String productCode;
    private int quantity;

    public Smartphone(String productName,String productCode, int quantity){
        this.productName = productName;
        this.productCode = productCode;
        this.quantity = quantity;
    }
}
