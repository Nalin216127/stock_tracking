package com.example.task_02.ViewModel

import androidx.lifecycle.ViewModel
import com.example.task_02.Dao.SmartDatabase
import com.example.task_02.repository.SmartRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(private val smartRepository: SmartRepository):ViewModel() {

    val smartPhoneList get() =smartRepository.getAllData()

}
