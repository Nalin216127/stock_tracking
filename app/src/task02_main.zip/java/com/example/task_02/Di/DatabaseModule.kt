package com.example.task_02.Di

import android.content.Context
import com.example.task_02.Dao.SmartDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent

@InstallIn(SingletonComponent::class)
@Module
class DatabaseModule {
    @Provides
    fun provideUserDatabase(@ApplicationContext context: Context) : SmartDatabase =SmartDatabase.getDatabase(context)

    @Provides
    fun provideUserDao(smartDatabase: SmartDatabase) = smartDatabase.smartphoneDao()
}